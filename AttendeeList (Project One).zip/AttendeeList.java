import java.io.*;
import java.util.ArrayList;

public class AttendeeList {

    public static void main(String[] args) throws IOException {
        // File location for the list and the output file
        String file = "C:\\Users\\eleme\\Downloads\\CS 508 Project One Conference Attendee List.txt";
        String outputFile = "C:\\Users\\eleme\\Downloads\\Sorted Attendee List.txt";

        // Creates the ArrayList to hold the names'
        ArrayList<String> names = new ArrayList<>();

        // Read names from the file
        BufferedReader reader = new BufferedReader(new FileReader(file));
        String name;

        // Removes excess spaces and adds names to the ArrayList
        while ((name = reader.readLine()) != null) {
            name = name.trim().replaceAll("\\s+", " ");

            if (!name.isEmpty()) {
                names.add(name);
            }
        }

        reader.close();

        int count = names.size();

        // Remove duplicates
        int unique = 0;

        //Goes through each name and checks for duplicates, if there is one it will not add it to the unique list
        for (int i = 0; i < names.size(); i++) {
            boolean duplicate = false;

            for (int j = 0; j < unique; j++) {
                // Check for duplicates, if there is one stop checking
                if (names.get(i).equalsIgnoreCase(names.get(j))) {
                    duplicate = true;
                    break;
                }
            }
            // If no duplicate was found, add the name to the unique list
            if (!duplicate) {
                names.set(unique, names.get(i));
                unique++;
            }
        }

        // Remove duplicate entries from the end
        while (names.size() > unique) {
            names.remove(names.size() - 1);
        }

        // Sort names alphabetically using insertion sort
        for (int i = 1; i < names.size(); i++) {
            // Store the current name 
            String temp = names.get(i);
            //Compare to the previous name in the list
            int j = i - 1;
            // Move names that are greater than the current name one position to the right
            while (j >= 0 && names.get(j).compareToIgnoreCase(temp) > 0) {
                // Move the previous name one position to the right
                names.set(j + 1, names.get(j));
                // Move to the next previous name
                j--;
            }
            // Insert the current name into its correct position
            names.set(j + 1, temp);
        }


        // Print results 
        System.out.println("Total entries: " + count);
        System.out.println("Unique attendees: " + unique + "\n");
        System.out.println("Attendee Name");

        // Print names and save them to a file
        PrintWriter writer = new PrintWriter(new FileWriter(outputFile));

        // Print each of the sorted names
        for (int i = 0; i < names.size(); i++) {
            System.out.println(names.get(i));
            writer.println(names.get(i));
        }

        writer.close();

        System.out.println("\nSorted list saved to: " + outputFile);
    }
}


