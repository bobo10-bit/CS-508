import java.io.*;
import java.util.*;

public class Main {

    // Stores all EV records
    static ArrayList<EVRecord> records = new ArrayList<>();

    // Stores the information for each record
    static class EVRecord {
        String state, county;
        double percentEV;
        int totalEV, totalVehicles;

        EVRecord(String state, String county, double percentEV, int totalEV, int totalVehicles) {
            this.state = state;
            this.county = county;
            this.percentEV = percentEV;
            this.totalEV = totalEV;
            this.totalVehicles = totalVehicles;
        }
    }

    // Loads the CSV file and stores the records
    public static void loadData(String fileName) {
        try {
            BufferedReader br = new BufferedReader(new FileReader(fileName));
            String line;

            br.readLine(); // Skip the header

            while ((line = br.readLine()) != null) {
                // Separate the CSV values while keeping commas inside quotes
                String[] data = line.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)", -1);

                if (data.length < 10) {
                    continue;
                }

                // Get the values needed from each record
                String county = data[1].replace("\"", "").trim();
                String state = data[2].replace("\"", "").trim();
                int totalEV = Integer.parseInt(data[6].replace("\"", "").replace(",", "").trim());
                int totalVehicles = Integer.parseInt(data[8].replace("\"", "").replace(",", "").trim());
                double percentEV = Double.parseDouble(data[9].replace("\"", "").replace("%", "").trim());

                // Add the record to the ArrayList
                records.add(new EVRecord(state, county, percentEV, totalEV, totalVehicles));
            }

            br.close();
            System.out.println("Loaded " + records.size() + " records.");

        } catch (Exception e) {
            System.out.println("Error loading file: " + e.getMessage());
        }
    }

    //Search for records by state using linear search
    public static ArrayList<EVRecord> searchByState(String state) {
        ArrayList<EVRecord> results = new ArrayList<>();

        // Check each record for a matching state
        for (EVRecord record : records) {
            if (record.state.equalsIgnoreCase(state)) {
                results.add(record);
            }
        }

        return results;
    }

    // Sort records by EV percentage using exchange sort
    public static void sortByPercentEV() {

        // Compare records and move higher percentages toward the beginning
        for (int i = 0; i < records.size() - 1; i++) {
            for (int j = i + 1; j < records.size(); j++) {
                if (records.get(i).percentEV < records.get(j).percentEV) {

                    // Swap the records
                    EVRecord temp = records.get(i);
                    records.set(i, records.get(j));
                    records.set(j, temp);
                }
            }
        }
    }

    // Calculate statistics for the EV records
    public static void generateStatistics() {
        double totalPercent = 0;
        int totalEVs = 0;

        //Store the total EVs and vehicles for each state
        HashMap<String, int[]> stateTotals = new HashMap<>();

        for (EVRecord record : records) {
            totalPercent += record.percentEV;
            totalEVs += record.totalEV;

            // Create a new entry for states not already in the HashMap
            if (!stateTotals.containsKey(record.state)) {
                stateTotals.put(record.state, new int[2]);
            }

            // Add the record totals to its state
            stateTotals.get(record.state)[0] += record.totalEV;
            stateTotals.get(record.state)[1] += record.totalVehicles;
        }

        if (records.isEmpty()) {
            System.out.println("No records available.");
            return;
        }

        String highestState = "";
        double highestPercent = 0;

        // Find the state with the highest EV percentage
        for (String state : stateTotals.keySet()) {
            int[] totals = stateTotals.get(state);
            double percent = (double) totals[0] / totals[1] * 100;

            if (totals[1] > 0 && percent > highestPercent) {
                highestPercent = percent;
                highestState = state;
            }
        }

        // Display the calculated statistics
        System.out.printf("\nAverage EV Percentage: %.2f%%\n", totalPercent / records.size());
        System.out.println("Total Electric Vehicles: " + totalEVs);
        System.out.printf("State with Highest EV Percentage: %s (%.2f%%)\n",
                highestState, highestPercent);
    }

    public static void main(String[] args) {

        // Load the EV dataset
        loadData("C:\\Users\\eleme\\Downloads\\CS 508 Project Two Data Set.csv");

        // Change this abbreviation to search another state
        String searchState = "HI";
        ArrayList<EVRecord> results = searchByState(searchState);

        System.out.println("\nRecords for " + searchState + ": " + results.size());

        // Sort records from highest to lowest EV percentage
        sortByPercentEV();

        System.out.println("\nTop 10 Records:");

        // Keep track of counties that have already been displayed
        HashSet<String> displayed = new HashSet<>();
        int count = 0;

        for (EVRecord record : records) {
            String key = record.state + "-" + record.county;

            // Only display each state and county combination once
            if (displayed.add(key)) {
                System.out.printf("%s - %s - %.2f%%\n",
                        record.state, record.county, record.percentEV);
                count++;
            }

            if (count == 10) {
                break;
            }
        }

        // Display the final statistics
        generateStatistics();
    }
}
